import { useEffect, useState } from 'react';
import { ChevronRight, Clock, Plus, X } from 'lucide-react';
import type { Story } from '@/types';
import { useAppStore } from '@/store/useAppStore';
import { Avatar } from '@/components/UserCard';

export default function StoriesBar() {
  const { stories, markStorySeen, profile } = useAppStore();
  const [viewing, setViewing] = useState<Story | null>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setViewing(null);
    if (viewing) {
      markStorySeen(viewing.id);
      window.addEventListener('keydown', onKey);
    }
    return () => window.removeEventListener('keydown', onKey);
  }, [viewing, markStorySeen]);

  const unseenCount = stories.filter((s) => !s.seen).length;

  return (
    <>
      <section className="rounded-2xl border border-slate-800 bg-slate-900/70 p-4">
        <div className="mb-3 flex items-center gap-2">
          <Clock size={17} className="text-cyan-400" />
          <h2 className="text-base font-bold text-white">الحالات</h2>
          <span className="text-[11px] text-slate-500">تختفي بعد ٢٤ ساعة · تظهر لجهات اتصالك فقط</span>
        </div>
        <div className="flex gap-4 overflow-x-auto pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          <div className="flex shrink-0 flex-col items-center gap-1.5">
            <div className="relative">
              <img src={profile.avatar} alt="" className="h-16 w-16 rounded-full border-2 border-slate-700 object-cover" />
              <span className="absolute -bottom-0.5 -left-0.5 flex h-5 w-5 items-center justify-center rounded-full border-2 border-slate-900 bg-cyan-500 text-white">
                <Plus size={12} strokeWidth={3} />
              </span>
            </div>
            <span className="max-w-16 truncate text-[11px] text-slate-400">حالتك</span>
          </div>

          {stories.map((story) => (
            <button
              key={story.id}
              onClick={() => setViewing(story)}
              className="flex shrink-0 flex-col items-center gap-1.5 transition active:scale-95"
            >
              <span
                className={`rounded-full p-[2.5px] ${
                  story.seen
                    ? 'bg-slate-700'
                    : 'bg-[conic-gradient(#06b6d4,#a855f7,#06b6d4)]'
                }`}
              >
                <img src={story.user.avatar} alt="" className="h-14 w-14 rounded-full border-2 border-slate-900 object-cover" />
              </span>
              <span className={`max-w-16 truncate text-[11px] ${story.seen ? 'text-slate-500' : 'text-slate-200'}`}>
                {story.user.name.split(' ')[0]}
              </span>
            </button>
          ))}
        </div>
        {unseenCount > 0 && (
          <p className="mt-2 text-[11px] text-cyan-400">{unseenCount} حالات جديدة</p>
        )}
      </section>

      {viewing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 p-4" onClick={() => setViewing(null)}>
          <div className="relative max-h-[85vh] w-full max-w-sm overflow-hidden rounded-2xl" onClick={(e) => e.stopPropagation()}>
            <img src={viewing.imageUrl} alt="" className="h-auto w-full object-cover" />
            <div className="absolute inset-x-0 top-0 flex items-center gap-2 bg-gradient-to-b from-black/80 to-transparent p-3">
              <Avatar src={viewing.user.avatar} size="sm" />
              <div className="flex-1">
                <p className="text-sm font-bold text-white">{viewing.user.name}</p>
                <p className="text-[11px] text-slate-300">{viewing.createdAt}</p>
              </div>
              <button
                onClick={() => setViewing(null)}
                className="rounded-full bg-black/40 p-2 text-white transition hover:bg-black/70"
                aria-label="إغلاق"
              >
                <X size={18} />
              </button>
            </div>
            <button
              onClick={() => setViewing(null)}
              className="absolute inset-y-0 left-0 flex w-1/3 items-center justify-start pl-2 text-white/60"
              aria-label="التالي"
            >
              <ChevronRight size={32} />
            </button>
          </div>
        </div>
      )}
    </>
  );
}
